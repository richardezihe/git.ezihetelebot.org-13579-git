// BOT TELE
module.exports = {
  BOT_TOKEN: "8044523902:AAHJK10ZAZEZyUT9dPYvBDLzuf-PZYg8Jkc", // Token bot Telegram
  OWNER_ID: "8045084951", // ID pemilik bot
  allowedGroupIds: [-1002407105201, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};